import { useEffect, useState } from "react";
import axios from "axios";

const ChatComponent = ({ spkId, token }) => {
    const [messages, setMessages] = useState([]);
    const [message, setMessage] = useState("");

    // Ambil chat saat komponen pertama kali dirender
    useEffect(() => {
        axios.get(`http://localhost:8000/api/spk-chats/${spkId}`, {
            headers: { Authorization: `Bearer ${token}` }
        }).then(response => {
            setMessages(response.data);
        }).catch(error => {
            console.error("Error fetching messages:", error);
        });
    }, [spkId, token]);

    // Fungsi untuk mengirim pesan
    const sendMessage = async () => {
        if (!message.trim()) return;

        try {
            const response = await axios.post("http://localhost:8000/api/send-message", 
            { message, id_spk: spkId }, 
            { headers: { Authorization: `Bearer ${token}` } });

            setMessages([...messages, response.data.data]); // Update state dengan pesan baru
            setMessage(""); // Kosongkan input
        } catch (error) {
            console.error("Error sending message:", error);
        }
    };

    return (
        <div>
            <div className="chat-box">
                {messages.map((msg, index) => (
                    <p key={index}><strong>{msg.user?.name}:</strong> {msg.message}</p>
                ))}
            </div>
            <input 
                type="text" 
                value={message} 
                onChange={(e) => setMessage(e.target.value)} 
                placeholder="Type a message..."
            />
            <button onClick={sendMessage}>Send</button>
        </div>
    );
};

export default ChatComponent;
