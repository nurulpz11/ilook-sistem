import React, { useState, useEffect } from "react";
import Pusher from "pusher-js";

const ChatNotification = ({ selectedSpkId }) => {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    const pusher = new Pusher('b646c54d20b146c476dc', {
      cluster: 'ap1',
      encrypted: true,
    });

    const channel = pusher.subscribe(`spk-chat-notification.${selectedSpkId}`);
    channel.bind('chat.notification', (data) => {
      console.log('Received chat notification:', data);
      setNotifications((prevNotifications) => [
        ...prevNotifications,
        { message: `Pesan baru dari ${data.chat.user.name}` }
      ]);
    });

    return () => {
      pusher.unsubscribe(`spk-chat-notification.${selectedSpkId}`);
    };
  }, [selectedSpkId]);

  return (
    <div>
      <h3>Daftar Notifikasi untuk SPK #{selectedSpkId}</h3>
      {notifications.length > 0 ? (
        notifications.map((notif, index) => (
          <div key={index} className="notification-item">
            <p>{notif.message}</p>
          </div>
        ))
      ) : (
        <p>No new notifications</p>
      )}
    </div>
  );
};

export default ChatNotification;
