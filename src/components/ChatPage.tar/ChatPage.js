import React, { useState, useEffect } from "react";
import ChatNotification from "./ChatNotification"; // Pastikan ini sudah diimport dengan benar

const ChatPage = ({ id_spk }) => {
    const [messages, setMessages] = useState([]);  // State untuk menyimpan pesan

    // Fungsi untuk menangani pesan baru
    const handleNewMessage = (message) => {
        console.log("Pesan baru diterima:", message);

        // Menambahkan pesan baru ke state
        setMessages(prevMessages => [message, ...prevMessages]);
    };

    return (
        <div>
            <h2>Chat SPK {id_spk}</h2>

            {/* Pusher untuk menerima pesan */}
            <ChatNotification id_spk={id_spk} onNewMessage={handleNewMessage} />

            {/* Menampilkan daftar pesan */}
            <div style={{ maxHeight: '400px', overflowY: 'scroll' }}>
                {messages.length > 0 ? (
                    messages.map((msg, index) => (
                        <div key={index} style={{ padding: '10px', borderBottom: '1px solid #ccc' }}>
                            <p><strong>{msg.sender}</strong>: {msg.message}</p>
                            <p style={{ fontSize: '0.8em', color: 'gray' }}>{msg.timestamp}</p>
                        </div>
                    ))
                ) : (
                    <p>No messages yet</p>
                )}
            </div>
        </div>
    );
};

export default ChatPage;
